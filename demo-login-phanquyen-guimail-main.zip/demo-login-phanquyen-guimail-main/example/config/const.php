<?php
    define('FILE_ROOT', '/site/img/');
?>